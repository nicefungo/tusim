#!/usr/bin/env python3
"""Retain exact commands, output and status; never hide expected failures."""
import argparse
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/home/zxy/Workplace/projects/onnx-compiler')
WORK = Path('/home/zxy/.hermes/cache/scratch/tusim-dma-cleanup-20261024')
FLAGS = '-O1 -g -Wall -Wextra -std=c11 -fPIC -fsanitize=address,undefined -fno-omit-frame-pointer'

def run(name, args, cwd):
    env = dict(os.environ, LD_LIBRARY_PATH=str(cwd),
               ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
               UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
    with (WORK / (name + '.log')).open('w') as log:
        result = subprocess.run(args, cwd=cwd, env=env, stdout=log, stderr=subprocess.STDOUT)
    record = dict(name=name, command=args, cwd=str(cwd), exit=result.returncode)
    with (WORK / 'commands.jsonl').open('a') as out:
        out.write(json.dumps(record) + '\n')
    print(json.dumps(record), flush=True)
    return result.returncode

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=['baseline-san', 'final-live', 'final-san', 'snapshot'])
    opts = parser.parse_args()
    if opts.mode == 'baseline-san':
        dest = WORK / 'baseline-san'
        dest.mkdir(exist_ok=True)
        archive = subprocess.run(['git', 'archive', 'HEAD'], cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
        subprocess.run(['tar', '-xf', '-', '-C', str(dest)], input=archive, check=True)
        assert run('baseline-san-build', ['make', 'CFLAGS=' + FLAGS, 'LDFLAGS=-lm -fsanitize=address,undefined'], dest) == 0
        assert run('baseline-san-dma', ['make', 'test-dma', 'CFLAGS=' + FLAGS, 'LDFLAGS=-lm -fsanitize=address,undefined'], dest) != 0
        log = (WORK / 'baseline-san-dma.log').read_text()
        assert '3136 byte(s) leaked in 14 allocation(s)' in log
        print('RED verified: 3136 bytes / 14 allocations')
    elif opts.mode == 'final-live':
        assert run('final-clean', ['make', 'clean'], ROOT) == 0
        assert run('final-build', ['make'], ROOT) == 0
        assert run('final-quick', ['make', 'test-quick'], ROOT) == 0
        assert run('final-focused', ['make', 'test-config', 'test-dma-arbitration-sweep', 'test-dma-channel-sweep', 'test-dma-binding-sweep', 'test-dma-bus-width-sweep', 'test-scatter-gather', 'test-conv'], ROOT) == 0
    elif opts.mode == 'final-san':
        dest = WORK / 'final-san'
        dest.mkdir(exist_ok=True)
        archive = subprocess.run(['git', 'archive', 'HEAD'], cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
        subprocess.run(['tar', '-xf', '-', '-C', str(dest)], input=archive, check=True)
        import shutil
        shutil.copy2(ROOT / 'tests/test_dma.c', dest / 'tests/test_dma.c')
        assert run('final-san-build', ['make', 'CFLAGS=' + FLAGS, 'LDFLAGS=-lm -fsanitize=address,undefined'], dest) == 0
        assert run('final-san-dma-widths', ['make', 'test-dma', 'test-dma-drr-scan-width', 'test-dma-drr-stage-width', 'CFLAGS=' + FLAGS, 'LDFLAGS=-lm -fsanitize=address,undefined'], dest) == 0
    elif opts.mode == 'snapshot':
        dest = WORK / 'snapshot'
        dest.mkdir(exist_ok=True)
        tree = subprocess.check_output(['git', 'write-tree'], cwd=ROOT, text=True).strip()
        (WORK / 'snapshot-tree.txt').write_text(tree + '\n')
        archive = subprocess.run(['git', 'archive', tree], cwd=ROOT, check=True, stdout=subprocess.PIPE).stdout
        subprocess.run(['tar', '-xf', '-', '-C', str(dest)], input=archive, check=True)
        assert run('snapshot-build', ['make'], dest) == 0
        assert run('snapshot-quick', ['make', 'test-quick'], dest) == 0
        assert run('snapshot-focused', ['make', 'test-config', 'test-dma-arbitration-sweep', 'test-dma-channel-sweep', 'test-dma-binding-sweep', 'test-dma-bus-width-sweep', 'test-scatter-gather', 'test-conv'], dest) == 0
